package com.stepDefenition_WEB;

import org.junit.Assert;

import io.cucumber.java.en.Then;

public class EverestDashbaordTest {

	@Then("User verify dashbaord")
	public void users_successfully_logged_into_application() throws Exception {
		
		Assert.assertTrue(false);
	}
}
