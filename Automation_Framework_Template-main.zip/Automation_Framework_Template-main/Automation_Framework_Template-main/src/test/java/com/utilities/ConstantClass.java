package com.utilities;

public class ConstantClass {
	public static String webProbName="WebApp.properties";
	public static String apiProbName="API.properties";
	public static String MobileProbName="MobileApp.properties";
	
}
